Must press "CPU_Reset" button first!

-- Description: Top level controller that controls the OLED display.
--   After you press CPU_Reset_button, displays background LED_screen
--   and then overlays a zero or one (binary) for each of the 8 switches
--   and also prints the value as two Hex digits.
--   The values of the 8 switches are also shown on the 8 LEDs